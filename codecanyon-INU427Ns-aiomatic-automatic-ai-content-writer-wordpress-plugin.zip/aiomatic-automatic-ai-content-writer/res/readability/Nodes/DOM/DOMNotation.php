<?php

namespace fivefilters\Readability\Nodes\DOM;

use fivefilters\Readability\Nodes\NodeTrait;

class DOMNotation extends \DOMNotation
{
    use NodeTrait;
}
