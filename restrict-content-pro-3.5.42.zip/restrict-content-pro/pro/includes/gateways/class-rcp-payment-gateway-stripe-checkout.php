<?php
/**
 * Payment Gateway For Stripe Checkout
 *
 * @deprecated 3.2
 *
 * @package     Restrict Content Pro
 * @subpackage  Classes/Gateways/Stripe Checkout
 * @copyright   Copyright (c) 2017, Pippin Williamson
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.5
*/

class RCP_Payment_Gateway_Stripe_Checkout extends RCP_Payment_Gateway_Stripe {

}
